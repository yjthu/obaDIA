
echo Begin Diff Analysis :
date
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Diff
sh .diffP.sh >.diffP.sh.o 2>.diffP.sh.e

echo Begin Annotation:
date
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Anno
sh .annoP.sh /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/.seq.input >.annoP.sh.o 2>.annoP.sh.e

echo Begin Enrichment:
date
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/All
sh .All.enrichP.sh >.All.enrichP.sh.o 2>.All.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/BvsA
sh .BvsA.enrichP.sh >.BvsA.enrichP.sh.o 2>.BvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/CvsA
sh .CvsA.enrichP.sh >.CvsA.enrichP.sh.o 2>.CvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/DvsA
sh .DvsA.enrichP.sh >.DvsA.enrichP.sh.o 2>.DvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/EvsA
sh .EvsA.enrichP.sh >.EvsA.enrichP.sh.o 2>.EvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestDocker/obaDIA/example/protOut/Enrich/FvsA
sh .FvsA.enrichP.sh >.FvsA.enrichP.sh.o 2>.FvsA.enrichP.sh.e

echo All done!
date
