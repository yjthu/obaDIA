##=======================================================================================================================
setwd("Kegg.anno.output");
dat<-read.table("KEGG_classification_count.txt",skip=1,sep="\t")
dat<-dat[order(dat[,1]),]
dat<-subset(dat,dat[,1] !="Human Diseases")
percent=round(dat[,3]/72*100)

labels=as.factor(as.character(dat[,1]))
class<-levels(labels)
n<-floor(max(percent)*1.5/5)*5
a<-sapply(class,function(x) grep(x,labels)[[1]])
b<-c(a[-1],length(percent))
A<-a*1.75-0.5
B<-b*1.75-1.25
pos=(a+b)/2

cols<-rainbow(15)[(1:length(class))*3]
levels(labels)<-cols

png("KEGG_classification.png",width=12,height=9,res=72*4,units="in",type="cairo-png")
par(mar=c(5,20,4,4))
barplot(percent,beside=TRUE,col=as.character(labels),horiz=TRUE,xlim=c(0,max(percent)*1.5),space=0.75,main="KEGG Classification")
text(percent+0.5,(1:length(percent))*1.75-0.5,labels=dat[,3],cex=0.75)
text(-0.1,(1:length(percent))*1.75-0.5,labels=dat[,2],pos=2,xpd=TRUE)
mtext(side=1,line=2,"Percentage")
for(i in 1:length(class)){
	segments(n,A[i],n,B[i],lwd=4,col=cols[i],xpd=TRUE)
}
text(n+0.3,pos*1.75,labels=LETTERS[1:length(class)],xpd=TRUE,col="black",pos=4)
dev.off()

pdf("KEGG_classification.pdf",width=12,height=9)
par(mar=c(5,20,4,4))
barplot(percent,beside=TRUE,col=as.character(labels),horiz=TRUE,xlim=c(0,max(percent)*1.5),space=0.75,main="KEGG Classification")
text(percent+0.5,(1:length(percent))*1.75-0.5,labels=dat[,3],cex=0.75)
text(-0.1,(1:length(percent))*1.75-0.5,labels=dat[,2],pos=2,xpd=TRUE)
mtext(side=1,line=2,"Percentage")
for(i in 1:length(class)){
	segments(n,A[i],n,B[i],lwd=4,col=cols[i],xpd=TRUE)
}
text(n+0.3,pos*1.75,labels=LETTERS[1:length(class)],xpd=TRUE,col="black",pos=4)
dev.off()


##=======================================================================================================================
