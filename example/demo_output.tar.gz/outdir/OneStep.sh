
echo Begin Diff Analysis :
date
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Diff
sh .diffP.sh >.diffP.sh.o 2>.diffP.sh.e

echo Begin Annotaion:
date
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Anno
sh .annoP.sh /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/seq.fa >.annoP.sh.o 2>.annoP.sh.e

echo Begin Enrichment:
date
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/All
sh .All.enrichP.sh >.All.enrichP.sh.o 2>.All.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/BvsA
sh .BvsA.enrichP.sh >.BvsA.enrichP.sh.o 2>.BvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/CvsA
sh .CvsA.enrichP.sh >.CvsA.enrichP.sh.o 2>.CvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/DvsA
sh .DvsA.enrichP.sh >.DvsA.enrichP.sh.o 2>.DvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/EvsA
sh .EvsA.enrichP.sh >.EvsA.enrichP.sh.o 2>.EvsA.enrichP.sh.e
cd /storage/data/PROJECT/biouser1/TestPaper/obaDIA/example/outdir/Enrich/FvsA
sh .FvsA.enrichP.sh >.FvsA.enrichP.sh.o 2>.FvsA.enrichP.sh.e

echo All done!
date
