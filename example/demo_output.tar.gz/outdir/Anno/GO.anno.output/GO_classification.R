#====================================================================================================
setwd("GO.anno.output")
count<-read.table("GO_classification_count.txt",sep="\t",skip=1)
colnames(count)<-c("go","name","class","number")
count<-subset(count,number>554*0.001)
count<-count[order(count$name),]
count<-count[order(count$class),]
labels<-as.character(count$name)
charLn<-max(nchar(labels))

bar_dat<-count$number*100/554
ylab<-round(c(0.1,1,10,100)*554/100)

lns<-nchar(labels)#labels���ֽ���
lns[lns>45]<-45#����45�Ķ����45
x1<-1.75*(1:length(bar_dat))-11
y1<-rep(0.00002,length(bar_dat))
x0<-sapply(1:length(bar_dat),function(x) 1.75*x-lns[x]/5-0.5)
y0<-sapply(1:length(bar_dat),function(x) 10^(log10(0.07)+(log10(0.00002)-log10(0.07))*lns[x]/50))

n1<-grep("Biological",count$class)[1]
n2<-grep("Cellular",count$class)[1]
n3<-grep("Molecular",count$class)[1]
nodes<-c(n1,n2-1,n2,n3-1,n3,length(bar_dat))

pdf("GO_classification_bar.pdf",width=(length(labels)*1.75+14)*0.2,height=3+0.2*(charLn/2+4))
par(mar=c(charLn/2,10,4,5))
barplot(bar_dat,log="y",col="OliveDrab",yaxt="n",xaxt="n",space=0.75,ylim=c(0.1,120),main="Function Classification (GO)")
axis(side=2,at=c(0.1,1,10,100),labels=c(0.1,1,10,100))
axis(side=4,at=c(0.1,1,10,100),labels=ylab)
axis(side=1,at=(0:(length(labels)-1))*1.75+0.5,labels=rep("",length(labels)))
text(1:length(labels)*1.75+0.25,0.07,labels=labels,xpd=TRUE,srt=60,pos=2)

mtext(side=2,line=3,"Percent of proteins")
mtext(side=4,line=3,"Number of proteins")
for(a in nodes){
        segments(x0[a],y0[a],x1[a],y1[a],xpd=TRUE,lwd=1.5)
}
for(b in c(1,3,5)){
        segments(x1[nodes[b]],0.00002,x1[nodes[b+1]],0.00002,xpd=TRUE,lwd=1.5)
        text(x1[floor((nodes[b]+nodes[b+1])/2)],0.000018,count[floor((nodes[b]+nodes[b+1])/2),3],xpd=T,pos=1)
}
dev.off()

png("GO_classification_bar.png",width=(length(labels)*1.75+14)*0.2,height=3+0.2*(charLn/2+4),type="cairo-png",res=72*4,units="in")
par(mar=c(charLn/2,10,4,5))
barplot(bar_dat,log="y",col="OliveDrab",yaxt="n",xaxt="n",space=0.75,ylim=c(0.1,120),main="Function Classification (GO)")
axis(side=2,at=c(0.1,1,10,100),labels=c(0.1,1,10,100))
axis(side=4,at=c(0.1,1,10,100),labels=ylab)
axis(side=1,at=(0:(length(labels)-1))*1.75+0.5,labels=rep("",length(labels)))
text(1:length(labels)*1.75+0.25,0.07,labels=labels,xpd=TRUE,srt=60,pos=2)

mtext(side=2,line=3,"Percent of proteins")
mtext(side=4,line=3,"Number of proteins")
for(a in nodes){
        segments(x0[a],y0[a],x1[a],y1[a],xpd=TRUE,lwd=1.5)
}
for(b in c(1,3,5)){
        segments(x1[nodes[b]],0.00002,x1[nodes[b+1]],0.00002,xpd=TRUE,lwd=1.5)
        text(x1[floor((nodes[b]+nodes[b+1])/2)],0.000018,count[floor((nodes[b]+nodes[b+1])/2),3],xpd=T,pos=1)
}
dev.off()


#====================================================================================================
