Trinotate is an extension of the Trinity project (http://trinityrnaseq.github.io/)

Documentation is provided at http://trinityrnaseq.github.io/

For questions, comments, etc., contact us through the Trinity user group (https://groups.google.com/forum/#!forum/trinityrnaseq-users).

