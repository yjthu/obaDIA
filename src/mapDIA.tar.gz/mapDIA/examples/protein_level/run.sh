../../mapDIA input
